package tn.esprit.myjobfinderapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;

import tn.esprit.myjobfinderapplication.general.DatabaseContract;

public class ViewCompanyActivity extends AppCompatActivity {

    String TAG = "ViewCompanyActivity "; // Used for log printing
    Job employer; // Contains employer's information
    private DatabaseContract.DatabaseHelper databaseHelper;
    private SQLiteDatabase db;
    private String companyID; // in-app ID # for this company
    private LocationManager locationManager; // Used to get user's location
    // Views on screen:
    TextView idView;
    TextView descriptionView;
    TextView addressView;
    TextView miscView;
    TextView postView;
    TextView linkView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_company);


        // Initializing our location manager, letting us access device's location
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        // Prepping database
        databaseHelper = new DatabaseContract.DatabaseHelper(getApplicationContext());
        db = databaseHelper.getWritableDatabase();
        employer = new Job();

        // Getting the company's Name number from the bundle
        Bundle bundle = getIntent().getExtras();
        companyID = bundle.getString("ID");
        //Log.i(TAG, "Company ID is... " + companyID);
    }


    /**
     * This will display the data for the chosen company
     */
    public void displayCompanyData() {
        // First we need to get the view objects that are on the screen
        idView = (TextView) findViewById(R.id.company_id);
        descriptionView = (TextView) findViewById(R.id.company_description);
        addressView = (TextView) findViewById(R.id.company_address);
        postView = (TextView) findViewById(R.id.company_post);
        miscView = (TextView) findViewById(R.id.company_miscellaneous_notes);
        linkView = (TextView) findViewById(R.id.company_link);

        // Now we need to set the content of the views
        idView.setText(employer.getID());
        descriptionView.setText(employer.getDescription());
        addressView.setText(employer.getAddress());
        postView.setText(employer.getPost());
        miscView.setText(employer.getMisc());
        linkView.setText(employer.getLinkToJobPosting());

        // Giving this activity a new action bar title:
        setTitle(employer.getName());
    }

    /**
     * This method will read a company's data from the database, based on ID #
     */
    public void readCompanyData(String companyID) throws IOException {
        String[] projection = {
                DatabaseContract.CompanyDataTable._ID,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_NAME,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_DESCRIPTION,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_POST,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_LINK_TO_JOB_POSTING,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_MISCELLANEOUS,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_ADDRESS,
        };

        // I only want a company whose ID number matches the one passed to me in a bundle
        String[] selectionArgs = {String.valueOf(companyID)};

        // My cursor that I use to loop over query results
        Cursor cursor = db.query(
                DatabaseContract.CompanyDataTable.TABLE_NAME,  // The table to query
                projection,                               // The columns to return
                DatabaseContract.CompanyDataTable._ID + "=?",                                // The columns for the WHERE clause
                selectionArgs,                            // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                null                                 // The sort order
        );

        if (!(cursor.getCount() == 0)) {
            //Log.i(TAG, "Got results when searching database for companies user has entered.");
            // Now, look into the result and get the data
            cursor.moveToFirst();
            employer.setID(cursor.getString(0));
            employer.setName(cursor.getString(1));
            employer.setDescription(cursor.getString(2));
            employer.setPost(cursor.getString(3));
            employer.setLinkToJobPosting(cursor.getString(4));
            employer.setMisc(cursor.getString(5));
            employer.setAddress(cursor.getString(6));

        } else {
            //Log.i(TAG, "Could not find matches when searching database for companies user has entered.");
        }

    }


    @Override
    public void onResume() {
        // Displaying the company's data on the screen
        try {
            readCompanyData(companyID);
        } catch (IOException e) {

        }
        displayCompanyData();

        super.onResume();
    }

}