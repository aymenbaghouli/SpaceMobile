package tn.esprit.myjobfinderapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import tn.esprit.myjobfinderapplication.general.DatabaseContract;

public class AddJobActivity extends AppCompatActivity {


    private EditText employerNameEditText; // Box where user types employer's name
    private Job job; // Will contain an employer's information
    private DatabaseContract.DatabaseHelper databaseHelper;
    private SQLiteDatabase db;
    // create an activity with bundle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_job);


        // Initialize Database objects
        databaseHelper = new DatabaseContract.DatabaseHelper(getApplicationContext());
        db = databaseHelper.getWritableDatabase();

        job = new Job();

        // Getting the edit text box where user types employer's name
        employerNameEditText = (EditText) findViewById(R.id.company_name);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_company, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.save_company) {
            try {
                saveToDatabase();
            } catch (InterruptedException e) {

            }
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * This method will save a company's information to the database
     */
    public void saveToDatabase() throws InterruptedException {
        // Each of the textboxes the user typed into:
        EditText companyNameTextView = (EditText) findViewById(R.id.company_name);
        EditText companyPosition = (EditText) findViewById(R.id.company_position);
        EditText companyPositionPosting = (EditText) findViewById(R.id.company_position_posting);
        EditText companyAddress = (EditText) findViewById(R.id.company_location);
        EditText companyGoal = (EditText) findViewById(R.id.company_goal_mission_statement);
        EditText companyMisc = (EditText) findViewById(R.id.company_miscellaneous_notes);

        if(!companyNameTextView.getText().toString().equals("") &&
                !companyNameTextView.getText().toString().equals("")&&
        !companyPosition.getText().toString().equals("")&&
        !companyPositionPosting.getText().toString().equals("")&&
                !companyAddress.getText().toString().equals("")&&
                !companyGoal.getText().toString().equals("")&&
        !companyMisc.getText().toString().equals("")
        ){
            ContentValues values = new ContentValues();
            // These are retrieved from what the user typed in:
            values.put(DatabaseContract.CompanyDataTable.COLUMN_NAME_NAME, companyNameTextView.getText().toString());
            values.put(DatabaseContract.CompanyDataTable.COLUMN_NAME_DESCRIPTION, companyPosition.getText().toString());
            values.put(DatabaseContract.CompanyDataTable.COLUMN_NAME_POST, companyAddress.getText().toString());
            values.put(DatabaseContract.CompanyDataTable.COLUMN_NAME_ADDRESS, companyGoal.getText().toString());
            values.put(DatabaseContract.CompanyDataTable.COLUMN_NAME_MISCELLANEOUS, companyMisc.getText().toString());
            values.put(DatabaseContract.CompanyDataTable.COLUMN_NAME_LINK_TO_JOB_POSTING, companyPositionPosting.getText().toString());



            // Insert the new row, returning the primary key value of the new row
            db.insert(
                    DatabaseContract.CompanyDataTable.TABLE_NAME,
                    null,
                    values);


            // Closing this activity
            finish();
        }else{
            new AlertDialog.Builder(AddJobActivity.this)
                    .setTitle("Required fields")
                    .setMessage("be sure to fill in all the fields!")
                    .setCancelable(false)
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // Whatever...
                        }
                    }).show();
        }


    }

}