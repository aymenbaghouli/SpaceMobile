package tn.esprit.myjobfinderapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import tn.esprit.myjobfinderapplication.general.DatabaseContract;

import static java.util.Collections.emptyList;

public class MainActivity extends AppCompatActivity {


    private String TAG = "MainActivity "; // Used for log files
    public CompanyListAdapter adapter = null;
    private DatabaseContract.DatabaseHelper databaseHelper;
    private SQLiteDatabase db;
    private ArrayList<Job> listOfCompanies;
    private Menu mainActivityMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseContract.DatabaseHelper(getApplicationContext());
        db = databaseHelper.getWritableDatabase();
        try {
            listOfCompanies = getAllCompanies("name"); // Will contain all companies
        } catch (IOException e) {
            emptyList();
        }



        FloatingActionButton fab = (FloatingActionButton) findViewById (R.id.fab);

        fab.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick (View view) {
                startActivity(new Intent(MainActivity.this, AddJobActivity.class));
            }
        });


        RecyclerView recyclerView; // Contains all companies' names and urls


        // The RecyclerView which will get the new adapter
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // RecyclerView Adapter for the list of companies
        adapter = new CompanyListAdapter(listOfCompanies,getApplicationContext());
        recyclerView.setAdapter(adapter);
    }



    /**
     * This method will get all company names from the database.
     */
    public ArrayList<Job> getAllCompanies(String orderBy) throws IOException {
        // This will contain the names of all of the companies
        ArrayList<Job> jobList = new ArrayList<Job>();

        // Writing what columns we want from the table
        String[] projection = {
                DatabaseContract.CompanyDataTable._ID,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_NAME,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_DESCRIPTION,
                DatabaseContract.CompanyDataTable.COLUMN_NAME_POST,
        };

        // Organize company names in this order...
        String sortOrder;

        sortOrder = DatabaseContract.CompanyDataTable.COLUMN_NAME_NAME + " ASC";



        // My cursor that I use to loop over query results
        Cursor cursor = db.query(
                DatabaseContract.CompanyDataTable.TABLE_NAME,  // The table to query
                projection,                               // The columns to return
                null,                                // The columns for the WHERE clause
                null,                            // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                sortOrder                                 // Thcce sort order
        );

        // Now, we make an job object and put each row's data into it.
        // We then insert this into the ArrayList and move to the next row.
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Job job = new Job();
            //Log.i(TAG, "Company name is: " + cursor.getString(1));
            job.setID(Long.toString(cursor.getLong(0)));
            job.setName(cursor.getString(1));
            job.setDescription(cursor.getString(2));
            job.setPost(cursor.getString(3));
           // job.setLogoByteArray(cursor.getBlob(5));
            jobList.add(job);
            cursor.moveToNext();
        }

        //Log.i(TAG, "Companynameslist: " + jobList.toString());
        return jobList;
    }


    /**
     * This method lets a user delete a company
     *
     * @param view is the view a user clicked on
     */
    public void deleteCompany(final View view) {
        // Making a dialog box that will pop up for the user
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Delete Company?");
        builder.setMessage("Are you sure you want to delete this company?");
        builder.setIcon(R.drawable.ic_launcher);
        builder.setPositiveButton("Yes, Delete It", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
                // Getting the relativelayout holding this trash can and other things
                RelativeLayout parentView = (RelativeLayout) view.getParent();
                // Getting the textview holding the company's ID number
                TextView idView = (TextView) parentView.getChildAt(1);
                // This is the actual ID number
                String idNumber = idView.getText().toString();
                // Deleting from the database:
                db.delete(DatabaseContract.CompanyDataTable.TABLE_NAME, DatabaseContract.CompanyDataTable._ID + "=?", new String[]{idNumber});
                // And refreshing the layout
                try {
                    refreshListOfCompanies();
                } catch (IOException e) {
                    Log.e("refresh erreur",e.toString());
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    /**
     * This method can be called from anywhere to refresh the list of companies in this activity
     */
    private void refreshListOfCompanies() throws IOException {
        if (adapter != null) {
            // First we clear the list of companies that the adapter is using:
            listOfCompanies.clear();
            // Now we update the list of companies:
            listOfCompanies.addAll(getAllCompanies("name"));
            // And lastly we tell the adapter to get new data:
            adapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        try {
            refreshListOfCompanies();
        } catch (IOException e) {
            Log.e("refresh erreur",e.toString());
        }
    }
}