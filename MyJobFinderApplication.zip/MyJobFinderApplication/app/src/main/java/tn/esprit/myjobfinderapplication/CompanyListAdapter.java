package tn.esprit.myjobfinderapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import static tn.esprit.myjobfinderapplication.R.drawable.ic_launcher_background;


public class CompanyListAdapter extends RecyclerView.Adapter<CompanyListAdapter.ViewHolder> {
    private List<Job> employerList;
    private Context context;

    public CompanyListAdapter(List<Job> employerList, Context context) {
        this.employerList = employerList;
        this.context = context;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout innerLayout;
        TextView companyIDView;
        TextView companyNameView;
        TextView websiteView;
        TextView positionLabelView;
        TextView positionView;
        ImageView positionImageView;
        TextView stepView;
        ImageView companyLogo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            innerLayout = (RelativeLayout) itemView.findViewById(R.id.relative_layout);
            companyIDView = (TextView) itemView.findViewById(R.id.id);
            companyNameView = (TextView) itemView.findViewById(R.id.name);
            websiteView = (TextView) itemView.findViewById(R.id.website);
            positionLabelView = (TextView) itemView.findViewById(R.id.position_label);
            positionView = (TextView) itemView.findViewById(R.id.position);
            positionImageView = (ImageView) itemView.findViewById(R.id.position_image);
            stepView = (TextView) itemView.findViewById(R.id.step);
            companyLogo = (ImageView) itemView.findViewById(R.id.companyLogo);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.listitem, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        //Getting current Job from this position
        Job job = employerList.get(position);

        // Now we can fill the layout with the right values
        // Logo for company:
        if (job != null) {
            holder.companyLogo.setImageDrawable(context.getResources().getDrawable(ic_launcher_background));
            holder.companyLogo.setVisibility(View.VISIBLE);
        } else holder.companyLogo.setVisibility(View.INVISIBLE);
        // Now let's set the text on the screen for this job:
        holder.companyIDView.setText(job.getID());
        holder.companyNameView.setText("Company Name :");
        holder.websiteView.setText(job.getName());

        // If they don't put in a website, hide this field
        if (job.getPost() == null) {
            holder.websiteView.setVisibility(View.GONE);
        }   else{
                     if (job.getPost().length() == 0) {
                        holder.websiteView.setVisibility(View.GONE);
                    } else {
                         // There is a website, so show this field:
                         holder.websiteView.setVisibility(View.VISIBLE);
                     }
        }

        holder.positionView.setText(job.getName());
        // If they don't put in a position, hide this field


        // If they don't put in a website, hide this field
        if (job.getPost() == null) {

        }else {
            if (job.getName().length() == 0) {
                holder.positionView.setVisibility(View.GONE);
                holder.positionLabelView.setVisibility(View.GONE);
                holder.positionImageView.setVisibility(View.GONE);
            } else {
                // They did enter a position, so show this field:
                holder.positionView.setVisibility(View.VISIBLE);
                holder.positionLabelView.setVisibility(View.VISIBLE);
                holder.positionImageView.setVisibility(View.VISIBLE);
            }
        }
        // If they have started, show most recent step, else don't
        if (job.getDescription() != null) {
            holder.stepView.setText(job.getDescription());
        } else {
            holder.stepView.setText("No description");
        }

        holder.innerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Making an intent to open ViewCompanyActivity
                Intent startViewCompanyIntent = new Intent(v.getContext(), ViewCompanyActivity.class);
                // Bundle to store things in
                Bundle bundle = new Bundle();
                // Use this name when starting a new activity
                bundle.putString("ID", holder.companyIDView.getText().toString());
                startViewCompanyIntent.putExtras(bundle);
                // Creating an intent to start the window
                v.getContext().startActivity(startViewCompanyIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return employerList != null ? employerList.size() : 0;
    }
}