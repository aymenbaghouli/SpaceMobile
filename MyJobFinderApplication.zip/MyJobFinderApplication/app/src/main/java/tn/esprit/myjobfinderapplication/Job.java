package tn.esprit.myjobfinderapplication;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Christina Aiello on 3/22/2015.
 */
public class Job {
    private String id;
    private String name;
    private String description;
    private String misc;
    private String post;
    private String address;
    private String linkToJobPosting;

    public Job() {
    }

    /**
     * Getter for an employer object
     *
     * @return name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Getter for an employer object
     *
     * @return position
     */
    public String getDescription() {
        return this.description;
    }


    /**
     * Getter for an employer object
     *
     * @return position
     */
    public String getMisc() {
        return this.misc;
    }

    /**
     * Getter for an employer object
     *
     * @return post
     */
    public String getPost() {
        return this.post;
    }

    /**
     * Getter for an employer object
     *
     * @return address
     */
    public String getAddress() {
        return this.address;
    }


    public String getLinkToJobPosting() {

        return this.linkToJobPosting;
    }


    /**
     * Getter for an employer object
     * @return
     */
    public String getID() {
        return this.id;
    }

    /**
     * Setter for an employer object
     * @param id
     */
    public void setID(String id) {
        this.id = id;
    }

    /**
     * Setter for an employer object
     *
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter for an employer object
     *
     */
    public void setDescription(String description) {
        this.description = description;
    }


    /**
     * Setter for an employer object
     *
     */
    public void setMisc(String misc) {
        this.misc = misc;
    }

    /**
     * Setter for an employer object
     *
     */
    public void setPost(String post) {
        this.post = post;
    }

    /**
     * Setter for an employer object
     *
     */
    public void setAddress(String address) {
        this.address = address;
    }

    public void setLinkToJobPosting(String linkToJobPosting) {
        this.linkToJobPosting = linkToJobPosting;
    }
}